import express, { type NextFunction, type Request, type Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { getHome, getRawStreamResponse, getSong, getSuggestions, searchAll, searchSongs } from './provider.js';
import { normalizeSearchAll, normalizeSongSearch, normalizeSongs } from './normalize.js';
import { TtlCache } from './cache.js';

const app = express();
app.set('trust proxy', 1);
const cache = new TtlCache<any>(45_000, 100);

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: true }));
app.use(express.json({ limit: '64kb' }));
app.use(rateLimit({ windowMs: config.rateLimitWindowMs, limit: config.rateLimitMax, standardHeaders: 'draft-8', legacyHeaders: false }));

app.get('/v1/health', (_req, res) => res.json({ success: true, data: { service: 'vibemusic3d-proxy', timestamp: new Date().toISOString() } }));

app.get('/v1/home', async (_req, res) => {
  try {
    const key = 'home';
    let value = cache.get(key);
    if (!value) {
      value = (await getHome()).filter(Boolean);
      if (!value.length) throw new Error('home feed unavailable');
      cache.set(key, value);
    }
    res.json({ success: true, data: value });
  } catch (error) {
    res.status(502).json({ success: false, error: { code: 'UPSTREAM_ERROR', message: error instanceof Error ? error.message : 'home feed unavailable' } });
  }
});

app.get('/v1/search', async (req, res) => {
  const q = String(req.query.q ?? '').trim();
  if (!q) return res.status(400).json({ success: false, error: { code: 'BAD_QUERY', message: 'q is required' } });
  try {
    const key = `all:${q.toLowerCase()}`;
    let value = cache.get(key);
    if (!value) { value = normalizeSearchAll(await searchAll(q)); cache.set(key, value); }
    res.json({ success: true, data: value });
  } catch (error) { res.status(502).json({ success: false, error: { code: 'UPSTREAM_ERROR', message: error instanceof Error ? error.message : 'upstream error' } }); }
});

app.get('/v1/search/songs', async (req, res) => {
  const q = String(req.query.q ?? '').trim();
  const page = Math.max(0, Math.min(100, Number(req.query.page ?? 0) || 0));
  const limit = Math.max(1, Math.min(50, Number(req.query.limit ?? 20) || 20));
  if (!q) return res.status(400).json({ success: false, error: { code: 'BAD_QUERY', message: 'q is required' } });
  try {
    const key = `songs:${q.toLowerCase()}:${page}:${limit}`;
    let value = cache.get(key);
    if (!value) { value = normalizeSongSearch(await searchSongs(q, page, limit)); cache.set(key, value); }
    res.json({ success: true, data: value });
  } catch (error) { res.status(502).json({ success: false, error: { code: 'UPSTREAM_ERROR', message: error instanceof Error ? error.message : 'upstream error' } }); }
});

app.get('/v1/song/:id', async (req, res) => {
  const id = req.params.id?.trim();
  if (!id) return res.status(400).json({ success: false, error: { code: 'BAD_ID', message: 'song id required' } });
  try { res.json({ success: true, data: normalizeSongs(await getSong(id)) }); }
  catch (error) { res.status(404).json({ success: false, error: { code: 'SONG_NOT_FOUND', message: error instanceof Error ? error.message : 'song lookup failed' } }); }
});

app.get('/v1/song/:id/suggestions', async (req, res) => {
  try { res.json({ success: true, data: normalizeSongs(await getSuggestions(req.params.id, Math.min(25, Number(req.query.limit ?? 10) || 10))) }); }
  catch (error) { res.status(502).json({ success: false, error: { code: 'UPSTREAM_ERROR', message: error instanceof Error ? error.message : 'suggestions failed' } }); }
});

app.get('/v1/stream/:id', async (req, res) => {
  try {
    const upstream = await getRawStreamResponse(req.params.id, req.headers.range);
    if (!upstream.ok) {
      return res.status(502).json({
        success: false,
        error: { code: 'UPSTREAM_STREAM_ERROR', message: `upstream_stream_http_${upstream.status}` }
      });
    }
    res.status(upstream.status);
    for (const name of ['content-type','content-length','content-range','accept-ranges','cache-control']) {
      const value = upstream.headers.get(name); if (value) res.setHeader(name, value);
    }
    if (!upstream.body) return res.end();
    const reader = upstream.body.getReader();
    res.on('close', () => reader.cancel().catch(() => {}));
    const pump = async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (!res.write(Buffer.from(value))) await new Promise<void>(resolve => res.once('drain', resolve));
        }
        res.end();
      } catch { res.destroy(); }
    };
    void pump();
  } catch (error) {
    res.status(502).json({ success: false, error: { code: 'STREAM_UNAVAILABLE', message: error instanceof Error ? error.message : 'stream unavailable' } });
  }
});

app.use((_req, res) => res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'route not found' } }));

app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  res.status(500).json({ success: false, error: { code: 'INTERNAL_ERROR', message: error instanceof Error ? error.message : 'internal error' } });
});

export default app;
