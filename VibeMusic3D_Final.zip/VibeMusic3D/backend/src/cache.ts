export class TtlCache<T> {
  private readonly values = new Map<string, { value: T; expiresAt: number }>();
  constructor(private readonly ttlMs: number, private readonly maxEntries = 100) {}
  get(key: string): T | undefined {
    const item = this.values.get(key);
    if (!item) return undefined;
    if (item.expiresAt <= Date.now()) { this.values.delete(key); return undefined; }
    return item.value;
  }
  set(key: string, value: T) {
    if (this.values.size >= this.maxEntries) this.values.delete(this.values.keys().next().value!);
    this.values.set(key, { value, expiresAt: Date.now() + this.ttlMs });
  }
}
