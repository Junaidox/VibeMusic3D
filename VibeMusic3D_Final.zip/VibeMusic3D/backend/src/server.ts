import 'dotenv/config';
import app from './app.js';
import { config } from './config.js';

app.listen(config.port, () => console.log(`VibeMusic3D proxy listening on :${config.port}`));
