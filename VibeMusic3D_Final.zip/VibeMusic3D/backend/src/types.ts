export type Link = { quality?: string | null; url?: string | null };
export type Song = {
  id?: string | null; name?: string | null; year?: string | null; duration?: number | null;
  language?: string | null; url?: string | null; album?: { id?: string | null; name?: string | null; url?: string | null } | null;
  artists?: { primary?: Array<{id?:string|null;name?:string|null;type?:string|null;image?:Link[]|null;url?:string|null}> | null; all?: Array<{id?:string|null;name?:string|null}> | null } | null;
  image?: Link[] | null; streamUrl?: string | null; downloadUrl?: Link[] | null;
  [key:string]: unknown;
};
