export const config = {
  port: Number(process.env.PORT ?? 8787),
  upstreamBaseUrl: (process.env.UPSTREAM_BASE_URL ?? 'https://saavn.sumit.co/api').replace(/\/$/, ''),
  publicBaseUrl: (process.env.PUBLIC_BASE_URL ?? 'http://10.0.2.2:8787').replace(/\/$/, ''),
  rateLimitWindowMs: Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60_000),
  rateLimitMax: Number(process.env.RATE_LIMIT_MAX ?? 120),
};
