import { config } from './config.js';
import type { Song } from './types.js';

const headers = {
  'user-agent': 'VibeMusic3D/1.0 (+personal music client)',
  'accept': 'application/json',
};

async function fetchJson(path: string, init?: RequestInit) {
  const response = await fetch(`${config.upstreamBaseUrl}${path}`, {
    ...init,
    headers: { ...headers, ...(init?.headers ?? {}) },
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new Error(`upstream_http_${response.status}`);
  const data: any = await response.json();
  if (data?.success === false) throw new Error(data.message ?? 'upstream_request_failed');
  return data;
}

function bestLink(links: any): string | null {
  if (!Array.isArray(links)) return null;
  const score = (q: string | undefined | null) => {
    const x = (q ?? '').toLowerCase();
    if (x.includes('320')) return 320;
    if (x.includes('500')) return 500;
    if (x.includes('160')) return 160;
    if (x.includes('96')) return 96;
    if (x.includes('150')) return 150;
    return 0;
  };
  return [...links].sort((a,b) => score(b?.quality) - score(a?.quality)).map(x => x?.url).find(Boolean) ?? null;
}

export function normalizeSong(raw: Song): Song {
  const id = raw.id ?? '';
  return {
    ...raw,
    id,
    name: raw.name ?? 'Unknown title',
    artists: raw.artists ?? { primary: [], all: [] },
    image: raw.image ?? [],
    streamUrl: `${config.publicBaseUrl}/v1/stream/${encodeURIComponent(id)}`,
  };
}

export async function searchAll(query: string) { return fetchJson(`/search?query=${encodeURIComponent(query)}`); }
export async function getHome() {
  const queries = ['Trending Hindi', 'New Hindi Songs', 'Arijit Singh', 'Bollywood Hits'];
  return Promise.all(queries.map(async (query) => {
    try {
      const body: any = await searchSongs(query, 0, 12);
      return { title: query, songs: (body?.data?.results ?? []).map(normalizeSong).filter((song: Song) => Boolean(song.id)) };
    } catch {
      return null;
    }
  }));
}
export async function searchSongs(query: string, page = 0, limit = 20) { return fetchJson(`/search/songs?query=${encodeURIComponent(query)}&page=${page}&limit=${limit}`); }
export async function getSong(id: string) { return fetchJson(`/songs/${encodeURIComponent(id)}`); }
export async function getSuggestions(id: string, limit = 10) { return fetchJson(`/songs/${encodeURIComponent(id)}/suggestions?limit=${limit}`); }

export async function getRawStreamResponse(id: string, range?: string): Promise<Response> {
  const songResponse: any = await getSong(id);
  const song = songResponse?.data?.[0];
  const url = bestLink(song?.downloadUrl);
  if (!url) throw new Error('stream_not_available');
  return fetch(url, {
    headers: range ? { ...headers, range } : headers,
    signal: AbortSignal.timeout(20_000),
    redirect: 'follow',
  });
}
