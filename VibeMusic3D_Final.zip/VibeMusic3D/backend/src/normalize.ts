import { normalizeSong } from './provider.js';

export function normalizeSearchAll(body: any) {
  const data = body?.data ?? {};
  return {
    songs: { total: data.songs?.total ?? 0, start: data.songs?.start ?? 0, results: (data.songs?.results ?? []).map(normalizeSong) },
    albums: { total: data.albums?.total ?? 0, start: data.albums?.start ?? 0, results: data.albums?.results ?? [] },
    artists: { total: data.artists?.total ?? 0, start: data.artists?.start ?? 0, results: data.artists?.results ?? [] },
    playlists: { total: data.playlists?.total ?? 0, start: data.playlists?.start ?? 0, results: data.playlists?.results ?? [] },
  };
}

export function normalizeSongSearch(body: any) {
  const data = body?.data ?? {};
  return {
    total: data.total ?? 0,
    start: data.start ?? 0,
    results: (data.results ?? []).map(normalizeSong),
  };
}

export function normalizeSongs(body: any) {
  return (body?.data ?? []).map(normalizeSong);
}
