import { describe, expect, it } from 'vitest';
import { normalizeSearchAll, normalizeSongSearch } from '../src/normalize.js';
import { normalizeSong } from '../src/provider.js';

describe('normalization', () => {
  it('keeps song identity and rewrites streamUrl to our proxy', () => {
    const song: any = normalizeSong({ id: 'abc', name: 'Song', downloadUrl: [{ quality: '320kbps', url: 'https://upstream/audio.mp3' }] });
    expect(song.id).toBe('abc');
    expect(song.streamUrl).toContain('/v1/stream/abc');
  });
  it('normalizes search payloads defensively', () => {
    expect(normalizeSongSearch({ data: { total: 1, start: 0, results: [{ id: '1', name: 'A' }] } }).results).toHaveLength(1);
    expect(normalizeSearchAll({ data: {} }).songs.results).toEqual([]);
  });
});
