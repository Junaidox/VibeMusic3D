# VibeMusic3D Proxy Backend

Node.js 20+ backend that normalizes the upstream unofficial JioSaavn API into a small app-specific contract.

## Endpoints

- `GET /v1/health`
- `GET /v1/home`
- `GET /v1/search?q=...`
- `GET /v1/search/songs?q=...&page=0&limit=20`
- `GET /v1/song/:id`
- `GET /v1/song/:id/suggestions`
- `GET /v1/stream/:id`

## Local development

Requires Node.js 20+.

```bash
npm install
npm run typecheck
npm test
npm start
```

For an Android emulator, default `PUBLIC_BASE_URL=http://10.0.2.2:8787`.
For a physical phone, set `PUBLIC_BASE_URL` to the host PC's LAN address, e.g. `http://192.168.1.20:8787`.
For a public deployment, use HTTPS.
