$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Test-Path "gradle\wrapper\gradle-wrapper.jar")) {
  throw "Gradle wrapper JAR is missing. Open the project once in Android Studio and let Gradle sync, or generate the wrapper with a local Gradle installation."
}
& .\gradlew.bat :app:assembleRelease
Write-Host "APK: app\build\outputs\apk\release\app-release.apk"
