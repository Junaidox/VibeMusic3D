package com.junaid.vibemusic3d

import org.junit.Assert.assertEquals
import org.junit.Test

class AppRouteTest {
    @Test
    fun topLevelRouteContractsAreStable() {
        val routes = listOf("Home", "Search", "Library")
        assertEquals(3, routes.distinct().size)
    }
}
