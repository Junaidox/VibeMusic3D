package com.junaid.vibemusic3d.feature.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.junaid.vibemusic3d.feature.common.SongRow
import com.junaid.vibemusic3d.playback.PlaybackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistDetailScreen(
    viewModel: PlaylistDetailViewModel = hiltViewModel(),
    libraryViewModel: LibraryViewModel,
    playbackViewModel: PlaybackViewModel,
    onBack: () -> Unit
) {
    val playlist by viewModel.playlist.collectAsStateWithLifecycle()
    val songs by viewModel.songs.collectAsStateWithLifecycle()
    val favorites by libraryViewModel.favorites.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    if (showAdd) {
        ModalBottomSheet(
            onDismissRequest = { showAdd = false },
            sheetState = sheetState
        ) {
            LazyColumn(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    Text("Add from liked songs", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 8.dp))
                }
                if (favorites.isEmpty()) item {
                    Text("Like songs first, then add them to this playlist.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(favorites, key = { it.id }) { song ->
                    val alreadyAdded = songs.any { it.id == song.id }
                    SongRow(
                        song = song,
                        onPlay = { playbackViewModel.play(song, favorites) },
                        trailingAction = {
                            IconButton(
                                enabled = !alreadyAdded,
                                onClick = { viewModel.add(song) }
                            ) {
                                Icon(Icons.Default.Add, if (alreadyAdded) "Already added" else "Add to playlist")
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text(playlist?.name ?: "Playlist", style = MaterialTheme.typography.titleLarge, maxLines = 1)
                Text("${songs.size} songs", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add songs") }
        }

        if (playlist == null) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Playlist not found")
            }
        } else if (songs.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("This playlist is empty", style = MaterialTheme.typography.headlineSmall)
                Text("Tap + to add songs from your liked collection.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    SongRow(
                        song = song,
                        onPlay = { playbackViewModel.play(song, songs) },
                        trailingAction = {
                            IconButton(onClick = { viewModel.remove(song) }) {
                                Icon(Icons.Default.DeleteOutline, "Remove ${song.title}")
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(100.dp)) }
            }
        }
    }
}
