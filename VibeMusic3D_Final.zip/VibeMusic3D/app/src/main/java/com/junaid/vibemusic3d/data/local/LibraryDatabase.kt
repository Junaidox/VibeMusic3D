package com.junaid.vibemusic3d.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [SongEntity::class, FavoriteEntity::class, PlaylistEntity::class, PlaylistSongCrossRef::class, RecentPlayEntity::class],
    version = 2,
    exportSchema = true
)
abstract class LibraryDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao
}
