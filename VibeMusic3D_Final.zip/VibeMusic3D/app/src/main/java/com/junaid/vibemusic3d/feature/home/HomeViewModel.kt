package com.junaid.vibemusic3d.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.junaid.vibemusic3d.domain.model.HomeSection
import com.junaid.vibemusic3d.domain.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val loading: Boolean = true,
    val sections: List<HomeSection> = emptyList(),
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: MusicRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(loading = true, error = null)
            repository.getHome().onSuccess { _uiState.value = HomeUiState(false, it) }
                .onFailure { _uiState.value = HomeUiState(false, error = it.message ?: "Unable to load music") }
        }
    }
}
