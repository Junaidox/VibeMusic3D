package com.junaid.vibemusic3d.data.di

import com.junaid.vibemusic3d.data.local.LibraryDao
import com.junaid.vibemusic3d.data.local.LibraryRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {
    @Provides
    @Singleton
    fun provideLibraryRepository(dao: LibraryDao) = LibraryRepository(dao)
}
