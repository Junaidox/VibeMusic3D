package com.junaid.vibemusic3d

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VibeMusicApplication : Application()
