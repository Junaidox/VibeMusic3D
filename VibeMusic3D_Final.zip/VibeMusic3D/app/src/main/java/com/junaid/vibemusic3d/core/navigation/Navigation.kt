package com.junaid.vibemusic3d.core.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.junaid.vibemusic3d.feature.home.HomeScreen
import com.junaid.vibemusic3d.feature.library.LibraryScreen
import com.junaid.vibemusic3d.feature.library.PlaylistDetailScreen
import com.junaid.vibemusic3d.feature.library.LibraryViewModel
import com.junaid.vibemusic3d.feature.player.MiniPlayer
import com.junaid.vibemusic3d.feature.player.PlayerScreen
import com.junaid.vibemusic3d.feature.search.SearchScreen
import com.junaid.vibemusic3d.playback.PlaybackViewModel

private object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val PLAYER = "player"
    const val PLAYLIST = "playlist/{playlistId}"

    fun playlist(id: Long) = "playlist/$id"
}

data class TopLevelDestination(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

private val destinations = listOf(
    TopLevelDestination(Routes.HOME, "Home", Icons.Default.Home),
    TopLevelDestination(Routes.SEARCH, "Search", Icons.Default.Search),
    TopLevelDestination(Routes.LIBRARY, "Library", Icons.Default.LibraryMusic)
)

@Composable
fun VibeMusicApp() {
    val navController = rememberNavController()
    val entry by navController.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val playbackViewModel: PlaybackViewModel = hiltViewModel()
    val libraryViewModel: LibraryViewModel = hiltViewModel()
    val playbackState by playbackViewModel.state.collectAsStateWithLifecycle()
    val isPlayer = route == Routes.PLAYER
    val isPlaylist = route == Routes.PLAYLIST

    Scaffold(
        bottomBar = {
            if (!isPlayer && !isPlaylist) {
                Column(Modifier.fillMaxWidth()) {
                    playbackState.currentSong?.let { song ->
                        MiniPlayer(
                            song = song,
                            isPlaying = playbackState.isPlaying,
                            onPlayPause = playbackViewModel::toggle,
                            onOpen = { navController.navigate(Routes.PLAYER) },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    NavigationBar {
                        destinations.forEach { destination ->
                            NavigationBarItem(
                                selected = route == destination.route,
                                onClick = {
                                    navController.navigate(destination.route) {
                                        popUpTo(Routes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(destination.icon, destination.label) },
                                label = { Text(destination.label) }
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    libraryViewModel = libraryViewModel,
                    playbackViewModel = playbackViewModel
                )
            }
            composable(Routes.SEARCH) {
                SearchScreen(
                    libraryViewModel = libraryViewModel,
                    playbackViewModel = playbackViewModel
                )
            }
            composable(Routes.LIBRARY) {
                LibraryScreen(
                    viewModel = libraryViewModel,
                    playbackViewModel = playbackViewModel,
                    onOpenPlaylist = { navController.navigate(Routes.playlist(it)) }
                )
            }
            composable(Routes.PLAYER) {
                PlayerScreen(
                    onBack = { navController.popBackStack() },
                    viewModel = playbackViewModel,
                    libraryViewModel = libraryViewModel
                )
            }
            composable(
                route = Routes.PLAYLIST,
                arguments = listOf(navArgument("playlistId") { type = NavType.StringType })
            ) {
                PlaylistDetailScreen(
                    libraryViewModel = libraryViewModel,
                    playbackViewModel = playbackViewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
