package com.junaid.vibemusic3d.feature.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.junaid.vibemusic3d.domain.model.Song
import com.junaid.vibemusic3d.feature.common.MusicArt
import com.junaid.vibemusic3d.feature.common.SongRow
import com.junaid.vibemusic3d.feature.library.LibraryViewModel
import com.junaid.vibemusic3d.playback.PlaybackState
import com.junaid.vibemusic3d.playback.PlaybackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    onBack: () -> Unit,
    viewModel: PlaybackViewModel = hiltViewModel(),
    libraryViewModel: LibraryViewModel
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val favorites by libraryViewModel.favorites.collectAsStateWithLifecycle()
    val favoriteIds = favorites.asSequence().map { it.id }.toSet()
    var showQueue by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val song = state.currentSong

    if (showQueue) {
        ModalBottomSheet(
            onDismissRequest = { showQueue = false },
            sheetState = sheetState
        ) {
            QueueSheet(state, viewModel, onDismiss = { showQueue = false })
        }
    }

    BoxWithPlayerBackground(song) {
        if (song == null) {
            Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Nothing is playing", style = MaterialTheme.typography.headlineSmall)
                TextButton(onClick = onBack) { Text("Go back") }
            }
        } else {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                    Text("Now playing", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { showQueue = true }) { Icon(Icons.Default.QueueMusic, "Queue") }
                }

                MusicArt(
                    song.imageUrl,
                    Modifier.fillMaxWidth().weight(1f).clip(MaterialTheme.shapes.extraLarge),
                    28.dp
                )

                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(song.title, style = MaterialTheme.typography.headlineMedium, maxLines = 2)
                    Text(song.artistName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                val duration = state.durationMs.coerceAtLeast(1L)
                var isSeeking by remember { mutableStateOf(false) }
                var sliderPosition by remember { mutableFloatStateOf(0f) }
                LaunchedEffect(state.positionMs, state.durationMs, isSeeking) {
                    if (!isSeeking) {
                        sliderPosition = state.positionMs.coerceIn(0L, duration).toFloat()
                    }
                }
                Slider(
                    value = sliderPosition.coerceIn(0f, duration.toFloat()),
                    onValueChange = {
                        isSeeking = true
                        sliderPosition = it
                    },
                    onValueChangeFinished = {
                        isSeeking = false
                        viewModel.seek(sliderPosition.toLong())
                    },
                    valueRange = 0f..duration.toFloat()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(state.positionMs))
                    Text(formatTime(state.durationMs))
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.setShuffle(!state.shuffleEnabled) }) {
                        Icon(
                            Icons.Default.Shuffle,
                            "Shuffle",
                            tint = if (state.shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = viewModel::previous, modifier = Modifier.size(58.dp)) {
                        Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(36.dp))
                    }
                    Surface(
                        shape = CircleShape,
                        tonalElevation = 8.dp,
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        IconButton(onClick = viewModel::toggle, modifier = Modifier.size(78.dp)) {
                            Icon(
                                if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                if (state.isPlaying) "Pause" else "Play",
                                Modifier.size(42.dp)
                            )
                        }
                    }
                    IconButton(onClick = viewModel::next, modifier = Modifier.size(58.dp)) {
                        Icon(Icons.Default.SkipNext, "Next", Modifier.size(36.dp))
                    }
                    IconButton(onClick = viewModel::cycleRepeat) {
                        Icon(
                            Icons.Default.Repeat,
                            "Repeat",
                            tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                state.error?.let { error ->
                    Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth())
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    IconButton(onClick = {
                        libraryViewModel.setFavorite(song, song.id !in favoriteIds)
                    }) {
                        Icon(
                            if (song.id in favoriteIds) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            if (song.id in favoriteIds) "Unlike" else "Like",
                            tint = if (song.id in favoriteIds) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun QueueSheet(
    state: PlaybackState,
    viewModel: PlaybackViewModel,
    onDismiss: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Queue", style = MaterialTheme.typography.headlineSmall)
                Text("${state.queue.size} songs", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close queue") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(state.queue, key = { _, song -> song.id }) { index, song ->
                SongRow(
                    song = song,
                    onPlay = {
                        viewModel.skipToQueueItem(index)
                        onDismiss()
                    },
                    isLiked = false
                )
            }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
private fun BoxWithPlayerBackground(song: Song?, content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = if (song == null) 0.25f else 0.7f),
                    MaterialTheme.colorScheme.background
                )
            )
        )
    ) { content() }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}
