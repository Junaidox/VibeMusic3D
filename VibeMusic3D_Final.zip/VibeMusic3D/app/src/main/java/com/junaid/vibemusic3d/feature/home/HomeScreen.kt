package com.junaid.vibemusic3d.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.junaid.vibemusic3d.domain.model.Song
import com.junaid.vibemusic3d.feature.library.LibraryViewModel
import com.junaid.vibemusic3d.feature.common.MusicArt
import com.junaid.vibemusic3d.playback.PlaybackViewModel

@Composable
fun HomeScreen(
    viewModel: HomeViewModel = hiltViewModel(),
    libraryViewModel: LibraryViewModel,
    playbackViewModel: PlaybackViewModel
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val favorites by libraryViewModel.favorites.collectAsStateWithLifecycle()
    val favoriteIds = favorites.asSequence().map { it.id }.toSet()

    when {
        state.loading && state.sections.isEmpty() -> LoadingHome()
        state.error != null && state.sections.isEmpty() -> ErrorHome(state.error.orEmpty(), viewModel::load)
        else -> LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            item {
                Column(Modifier.padding(top = 18.dp)) {
                    Text("VibeMusic", style = MaterialTheme.typography.displaySmall)
                    Text("Your music, with depth.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Surface(shape = RoundedCornerShape(30.dp), tonalElevation = 10.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("DISCOVER", style = MaterialTheme.typography.labelLarge)
                        Text("A richer way to listen.", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Real catalog data, fast search, background playback and a library built around your taste.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            items(state.sections, key = { it.title }) { section ->
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(section.title, style = MaterialTheme.typography.titleLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(section.songs, key = { it.id }) { song ->
                            SongTile(
                                song = song,
                                isLiked = song.id in favoriteIds,
                                onLike = { libraryViewModel.setFavorite(song, song.id !in favoriteIds) },
                                onPlay = { playbackViewModel.play(song, section.songs) }
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.size(90.dp)) }
        }
    }
}

@Composable
private fun SongTile(song: Song, isLiked: Boolean, onLike: () -> Unit, onPlay: () -> Unit) {
    Column(Modifier.size(156.dp).clickable(onClick = onPlay)) {
        Box {
            MusicArt(song.imageUrl, Modifier.size(156.dp), 22.dp)
            IconButton(
                onClick = onLike,
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Icon(
                    if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = if (isLiked) "Unlike ${song.title}" else "Like ${song.title}",
                    tint = if (isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Text(song.title, maxLines = 1, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
        Text(song.artistName, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LoadingHome() {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) { CircularProgressIndicator() }
}

@Composable
private fun ErrorHome(message: String, retry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Couldn't load music", style = MaterialTheme.typography.headlineSmall)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        TextButton(onClick = retry) { Icon(Icons.Default.Refresh, null); Text(" Retry") }
    }
}
