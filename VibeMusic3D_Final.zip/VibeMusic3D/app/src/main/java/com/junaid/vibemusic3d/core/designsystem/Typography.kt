package com.junaid.vibemusic3d.core.designsystem

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontWeight

val VibeMusicTypography = Typography().run {
    copy(
        headlineLarge = headlineLarge.copy(fontWeight = FontWeight.SemiBold),
        headlineMedium = headlineMedium.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = titleMedium.copy(fontWeight = FontWeight.Medium)
    )
}
