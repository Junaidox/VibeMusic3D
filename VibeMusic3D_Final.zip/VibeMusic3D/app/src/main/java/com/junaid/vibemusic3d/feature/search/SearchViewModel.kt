package com.junaid.vibemusic3d.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.junaid.vibemusic3d.domain.model.SearchResult
import com.junaid.vibemusic3d.domain.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val query: String = "",
    val loading: Boolean = false,
    val result: SearchResult? = null,
    val error: String? = null
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {
    private val queryFlow = MutableStateFlow("")
    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            queryFlow
                .debounce(400)
                .collectLatest { query ->
                    val clean = query.trim()
                    if (clean.isBlank()) {
                        _uiState.value = SearchUiState(query = query)
                        return@collectLatest
                    }

                    _uiState.value = _uiState.value.copy(query = query, loading = true, error = null, result = null)
                    repository.search(clean)
                        .onSuccess { result ->
                            _uiState.value = SearchUiState(query = query, result = result)
                        }
                        .onFailure { error ->
                            _uiState.value = SearchUiState(
                                query = query,
                                error = error.message ?: "Search failed"
                            )
                        }
                }
        }
    }

    fun onQueryChanged(query: String) {
        _uiState.value = _uiState.value.copy(query = query, error = null)
        queryFlow.value = query
    }

    fun retry() {
        val rawQuery = _uiState.value.query
        val cleanQuery = rawQuery.trim()
        if (cleanQuery.isBlank()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(loading = true, error = null)
            repository.search(cleanQuery)
                .onSuccess { result ->
                    _uiState.value = SearchUiState(query = rawQuery, result = result)
                }
                .onFailure { error ->
                    _uiState.value = SearchUiState(
                        query = rawQuery,
                        error = error.message ?: "Search failed"
                    )
                }
        }
    }
}
