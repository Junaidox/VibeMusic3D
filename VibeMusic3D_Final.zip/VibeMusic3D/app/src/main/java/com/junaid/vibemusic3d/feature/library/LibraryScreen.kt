package com.junaid.vibemusic3d.feature.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.junaid.vibemusic3d.feature.common.SongRow
import com.junaid.vibemusic3d.playback.PlaybackViewModel

@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    playbackViewModel: PlaybackViewModel,
    onOpenPlaylist: (Long) -> Unit
) {
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsStateWithLifecycle()
    var showCreate by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    val favoriteIds = remember(favorites) { favorites.asSequence().map { it.id }.toSet() }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("New playlist") },
            text = {
                OutlinedTextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    singleLine = true,
                    placeholder = { Text("Playlist name") }
                )
            },
            confirmButton = {
                Button(
                    enabled = playlistName.isNotBlank(),
                    onClick = {
                        viewModel.createPlaylist(playlistName)
                        playlistName = ""
                        showCreate = false
                    }
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreate = false }) { Text("Cancel") }
            }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Library", style = MaterialTheme.typography.displaySmall)
                    Text("Your saved music", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { showCreate = true }) {
                    Icon(Icons.Default.Add, "Create playlist")
                }
            }
        }
        if (recentlyPlayed.isNotEmpty()) {
            item {
                Text("Recently played", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
            }
            items(recentlyPlayed, key = { "recent-${it.id}" }) { song ->
                SongRow(
                    song = song,
                    onPlay = { playbackViewModel.play(song, recentlyPlayed) },
                    onLike = { viewModel.setFavorite(song, song.id !in favoriteIds) },
                    isLiked = song.id in favoriteIds
                )
            }
        }

        item {
            Text("Liked songs", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))
        }
        if (favorites.isEmpty()) {
            item { Text("Like a song from Search to save it here.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(favorites, key = { it.id }) { song ->
                SongRow(
                    song = song,
                    onPlay = { playbackViewModel.play(song, favorites) },
                    onLike = { viewModel.removeFavorite(song) },
                    isLiked = true
                )
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.QueueMusic, contentDescription = null)
                Text("Playlists", style = MaterialTheme.typography.titleLarge)
            }
        }
        if (playlists.isEmpty()) {
            item { Text("Create your first playlist with +.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(playlists, key = { it.id }) { playlist ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(playlist.name, style = MaterialTheme.typography.titleMedium)
                        Text("Playlist", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { onOpenPlaylist(playlist.id) }) {
                        Icon(Icons.Default.QueueMusic, "Open ${playlist.name}")
                    }
                    IconButton(onClick = { viewModel.deletePlaylist(playlist.id) }) {
                        Icon(Icons.Default.DeleteOutline, "Delete ${playlist.name}")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(100.dp)) }
    }
}
