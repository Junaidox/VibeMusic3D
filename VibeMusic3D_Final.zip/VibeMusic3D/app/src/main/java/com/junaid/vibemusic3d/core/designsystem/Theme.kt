package com.junaid.vibemusic3d.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFFEDE9FE),
    onPrimary = Color(0xFF211A30),
    primaryContainer = Color(0xFF34264A),
    onPrimaryContainer = Color(0xFFF4EFFF),
    secondary = Color(0xFFC7B8E8),
    onSecondary = Color(0xFF2D243C),
    secondaryContainer = Color(0xFF423754),
    onSecondaryContainer = Color(0xFFEADFFF),
    background = Color(0xFF08080B),
    onBackground = Color(0xFFF3EFF7),
    surface = Color(0xFF101014),
    onSurface = Color(0xFFF3EFF7),
    surfaceVariant = Color(0xFF19191F),
    onSurfaceVariant = Color(0xFFC8C3CE),
    outline = Color(0xFF45414B)
)


@Composable
fun VibeMusicTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = VibeMusicTypography,
        content = content
    )
}
