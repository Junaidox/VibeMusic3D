package com.junaid.vibemusic3d.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import dagger.hilt.android.qualifiers.ApplicationContext
import com.junaid.vibemusic3d.domain.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaybackController @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var controller: MediaController? = null

    private suspend fun getController(): MediaController = withContext(Dispatchers.Main.immediate) {
        controller ?: MediaController.Builder(
            context,
            SessionToken(context, ComponentName(context, MusicPlaybackService::class.java))
        ).buildAsync().await().also { mediaController ->
            controller = mediaController
            mediaController.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) = sync(mediaController)
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = sync(mediaController)
                override fun onPlaybackStateChanged(playbackState: Int) = sync(mediaController)
                override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) = sync(mediaController)
                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = sync(mediaController)
                override fun onRepeatModeChanged(repeatMode: Int) = sync(mediaController)
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    _state.value = _state.value.copy(error = error.message ?: "Playback error")
                }
            })
            sync(mediaController)
        }
    }

    suspend fun play(song: Song, queue: List<Song> = listOf(song)): Boolean {
        val c = getController()
        _state.value = _state.value.copy(error = null)
        val playablePairs = queue.mapNotNull { candidate ->
            candidate.toMediaItem()?.let { candidate to it }
        }
        if (playablePairs.isEmpty()) {
            _state.value = _state.value.copy(error = "This song has no playable stream")
            return false
        }
        val playable = playablePairs.map { it.second }
        val actualIndex = playablePairs.indexOfFirst { it.first.id == song.id }
        if (actualIndex < 0) {
            _state.value = _state.value.copy(error = "This song has no playable stream")
            return false
        }
        c.setMediaItems(playable, actualIndex, 0L)
        c.prepare()
        c.play()
        sync(c)
        return true
    }

    suspend fun toggle() {
        val c = getController()
        if (c.isPlaying) c.pause() else c.play()
        sync(c)
    }

    suspend fun seekTo(positionMs: Long) {
        getController().seekTo(positionMs)
    }

    suspend fun next() {
        getController().seekToNextMediaItem()
    }

    suspend fun previous() {
        getController().seekToPreviousMediaItem()
    }

    suspend fun setQueue(queue: List<Song>) {
        val c = getController()
        val playable = queue.mapNotNull { it.toMediaItem() }
        c.setMediaItems(playable)
        c.prepare()
        sync(c)
    }

    suspend fun skipToQueueItem(index: Int) {
        val c = getController()
        if (index in 0 until c.mediaItemCount) {
            c.seekToDefaultPosition(index)
            c.play()
            sync(c)
        }
    }

    suspend fun setShuffleEnabled(enabled: Boolean) {
        val c = getController()
        c.shuffleModeEnabled = enabled
        sync(c)
    }

    suspend fun setRepeatMode(mode: Int) {
        val c = getController()
        c.repeatMode = mode
        sync(c)
    }

    suspend fun refresh() {
        controller?.let(::sync)
    }

    fun setError(message: String) {
        _state.value = _state.value.copy(error = message)
    }

    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }

    fun release() {
        controller?.release()
        controller = null
    }

    private fun sync(c: Player) {
        val current = c.currentMediaItem?.toSong()
        _state.value = PlaybackState(
            currentSong = current,
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = c.duration.takeIf { it >= 0 } ?: 0L,
            queue = (0 until c.mediaItemCount).mapNotNull { c.getMediaItemAt(it).toSong() },
            shuffleEnabled = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            error = _state.value.error
        )
    }

    private fun Song.toMediaItem(): MediaItem? {
        val url = streamUrl?.takeIf { it.startsWith("http://") || it.startsWith("https://") } ?: return null
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(url)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artistName)
                    .setAlbumTitle(albumName)
                    .setArtworkUri(imageUrl?.let(Uri::parse))
                    .build()
            )
            .build()
    }

    private fun MediaItem.toSong(): Song? {
        val title = mediaMetadata.title?.toString()?.takeIf { it.isNotBlank() } ?: return null
        return Song(
            id = mediaId,
            title = title,
            artistName = mediaMetadata.artist?.toString() ?: "Unknown artist",
            albumName = mediaMetadata.albumTitle?.toString(),
            imageUrl = mediaMetadata.artworkUri?.toString(),
            streamUrl = localConfiguration?.uri?.toString(),
            durationMs = null
        )
    }
}
