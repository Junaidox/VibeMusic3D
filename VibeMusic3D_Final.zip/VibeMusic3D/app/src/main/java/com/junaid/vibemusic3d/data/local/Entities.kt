package com.junaid.vibemusic3d.data.local

import androidx.room.Entity
import androidx.room.ForeignKey

@Entity(tableName = "songs")
data class SongEntity(
    @androidx.room.PrimaryKey val id: String,
    val title: String,
    val artistName: String,
    val albumName: String?,
    val imageUrl: String?,
    val streamUrl: String?,
    val durationMs: Long?,
    val url: String?
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @androidx.room.PrimaryKey val songId: String,
    val likedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "songId"],
    foreignKeys = [
        ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = SongEntity::class, parentColumns = ["id"], childColumns = ["songId"], onDelete = ForeignKey.CASCADE)
    ]
)
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: String,
    val position: Int
)

@Entity(tableName = "recent_plays")
data class RecentPlayEntity(
    @androidx.room.PrimaryKey val songId: String,
    val playedAt: Long = System.currentTimeMillis()
)
