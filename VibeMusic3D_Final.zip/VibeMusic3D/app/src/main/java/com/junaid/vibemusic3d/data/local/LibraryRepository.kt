package com.junaid.vibemusic3d.data.local

import com.junaid.vibemusic3d.domain.model.Playlist
import com.junaid.vibemusic3d.domain.model.Song
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class LibraryRepository @Inject constructor(private val dao: LibraryDao) {
    fun favorites(): Flow<List<Song>> = dao.favoriteSongs().map { list -> list.map { it.toDomain() } }
    fun recentlyPlayed(): Flow<List<Song>> = dao.recentSongs().map { list -> list.map { it.toDomain() } }
    fun playlists(): Flow<List<Playlist>> = dao.playlists().map { list -> list.map { Playlist(it.id, it.name) } }
    fun playlist(id: Long): Flow<Playlist?> = dao.playlist(id).map { it?.let { Playlist(it.id, it.name) } }
    fun playlistSongs(id: Long): Flow<List<Song>> = dao.playlistSongs(id).map { list -> list.map { it.toDomain() } }

    suspend fun setFavorite(song: Song, isLiked: Boolean) {
        if (isLiked) {
            dao.upsertSong(song.toEntity())
            dao.addFavorite(FavoriteEntity(song.id))
        } else {
            dao.deleteFavorite(song.id)
        }
    }

    suspend fun recordPlayed(song: Song) {
        dao.upsertSong(song.toEntity())
        dao.removeRecentPlay(song.id)
        dao.addRecentPlay(RecentPlayEntity(song.id))
        dao.trimRecent(30)
    }

    suspend fun createPlaylist(name: String): Long = dao.createPlaylist(PlaylistEntity(name = name))
    suspend fun deletePlaylist(id: Long) = dao.deletePlaylist(id)

    suspend fun addToPlaylist(playlistId: Long, song: Song) {
        dao.upsertSong(song.toEntity())
        dao.addToPlaylist(PlaylistSongCrossRef(playlistId, song.id, dao.nextPlaylistPosition(playlistId)))
    }

    suspend fun removeFromPlaylist(playlistId: Long, songId: String) = dao.removeFromPlaylist(playlistId, songId)
}

private fun SongEntity.toDomain() = Song(id, title, artistName, albumName, imageUrl, streamUrl, durationMs, url)
private fun Song.toEntity() = SongEntity(id, title, artistName, albumName, imageUrl, streamUrl, durationMs, url)
