package com.junaid.vibemusic3d.domain.model

data class Artist(
    val id: String,
    val name: String,
    val imageUrl: String?
)

data class Album(
    val id: String,
    val name: String,
    val imageUrl: String?,
    val artistName: String?
)

data class Song(
    val id: String,
    val title: String,
    val artistName: String,
    val albumName: String?,
    val imageUrl: String?,
    val streamUrl: String?,
    val durationMs: Long?,
    val url: String? = null
)

data class SearchResult(
    val songs: List<Song>,
    val albums: List<Album>,
    val artists: List<Artist>
)

data class HomeSection(
    val title: String,
    val songs: List<Song>
)
