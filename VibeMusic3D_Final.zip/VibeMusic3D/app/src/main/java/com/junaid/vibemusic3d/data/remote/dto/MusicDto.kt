package com.junaid.vibemusic3d.data.remote.dto

import com.squareup.moshi.Json

data class ApiEnvelope<T>(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "data") val data: T? = null,
    @Json(name = "message") val message: String? = null
)

data class LinkDto(
    val quality: String? = null,
    val url: String? = null
)

data class ArtistMapDto(
    val id: String? = null,
    val name: String? = null,
    val type: String? = null,
    val image: List<LinkDto>? = null,
    val url: String? = null
)

data class ArtistMapsDto(
    val primary: List<ArtistMapDto>? = null,
    val featured: List<ArtistMapDto>? = null,
    val all: List<ArtistMapDto>? = null
)

data class AlbumRefDto(
    val id: String? = null,
    val name: String? = null,
    val url: String? = null
)

data class SongDto(
    val id: String? = null,
    val name: String? = null,
    val type: String? = null,
    val year: String? = null,
    val releaseDate: String? = null,
    val duration: Double? = null,
    val label: String? = null,
    val explicitContent: Boolean? = null,
    val playCount: Long? = null,
    val language: String? = null,
    val hasLyrics: Boolean? = null,
    val lyricsId: String? = null,
    val url: String? = null,
    val copyright: String? = null,
    val album: AlbumRefDto? = null,
    val artists: ArtistMapsDto? = null,
    val image: List<LinkDto>? = null,
    val streamUrl: String? = null,
    val downloadUrl: List<LinkDto>? = null
)

data class SearchSongsDto(
    val total: Int? = null,
    val start: Int? = null,
    val results: List<SongDto>? = null
)

data class SearchAlbumDto(
    val id: String? = null,
    val title: String? = null,
    val type: String? = null,
    val image: List<LinkDto>? = null,
    val artist: String? = null,
    val url: String? = null,
    val songCount: Int? = null
)

data class SearchArtistDto(
    val id: String? = null,
    val title: String? = null,
    val type: String? = null,
    val image: List<LinkDto>? = null,
    val url: String? = null
)

data class SearchAllDto(
    val songs: SearchSongsDto? = null,
    val albums: SearchContainerDto<SearchAlbumDto>? = null,
    val artists: SearchContainerDto<SearchArtistDto>? = null
)

data class SearchContainerDto<T>(
    val total: Int? = null,
    val start: Int? = null,
    val results: List<T>? = null
)

data class HomeSectionDto(
    val title: String? = null,
    val songs: List<SongDto>? = null
)
