package com.junaid.vibemusic3d.data.remote

import com.junaid.vibemusic3d.data.remote.dto.ApiEnvelope
import com.junaid.vibemusic3d.data.remote.dto.HomeSectionDto
import com.junaid.vibemusic3d.data.remote.dto.SearchSongsDto
import com.junaid.vibemusic3d.data.remote.dto.SearchAllDto
import com.junaid.vibemusic3d.data.remote.dto.SongDto
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface MusicApi {
    @GET("v1/home")
    suspend fun home(): ApiEnvelope<List<HomeSectionDto>>

    @GET("v1/search")
    suspend fun search(
        @Query("q") query: String,
        @Query("page") page: Int = 0,
        @Query("limit") limit: Int = 20
    ): ApiEnvelope<SearchAllDto>

    @GET("v1/search/songs")
    suspend fun searchSongs(
        @Query("q") query: String,
        @Query("page") page: Int = 0,
        @Query("limit") limit: Int = 20
    ): ApiEnvelope<SearchSongsDto>

    @GET("v1/song/{id}")
    suspend fun song(@Path("id") id: String): ApiEnvelope<List<SongDto>>

    @GET("v1/song/{id}/suggestions")
    suspend fun suggestions(
        @Path("id") id: String,
        @Query("limit") limit: Int = 10
    ): ApiEnvelope<List<SongDto>>
}
