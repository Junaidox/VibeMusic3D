package com.junaid.vibemusic3d.feature.library

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.junaid.vibemusic3d.data.local.LibraryRepository
import com.junaid.vibemusic3d.domain.model.Playlist
import com.junaid.vibemusic3d.domain.model.Song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlaylistDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: LibraryRepository
) : ViewModel() {
    private val playlistId: Long = checkNotNull(savedStateHandle.get<String>("playlistId")).toLong()

    val playlist: StateFlow<Playlist?> = repository.playlist(playlistId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val songs: StateFlow<List<Song>> = repository.playlistSongs(playlistId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(song: Song) = viewModelScope.launch { repository.addToPlaylist(playlistId, song) }
    fun remove(song: Song) = viewModelScope.launch { repository.removeFromPlaylist(playlistId, song.id) }
}
