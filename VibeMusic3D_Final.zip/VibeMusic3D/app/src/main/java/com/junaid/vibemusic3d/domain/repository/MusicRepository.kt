package com.junaid.vibemusic3d.domain.repository

import com.junaid.vibemusic3d.domain.model.HomeSection
import com.junaid.vibemusic3d.domain.model.SearchResult
import com.junaid.vibemusic3d.domain.model.Song

interface MusicRepository {
    suspend fun search(query: String): Result<SearchResult>
    suspend fun getSong(id: String): Result<Song>
    suspend fun getHome(): Result<List<HomeSection>>
}
