package com.junaid.vibemusic3d.playback

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import com.junaid.vibemusic3d.data.local.LibraryRepository
import com.junaid.vibemusic3d.domain.model.Song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlaybackViewModel @Inject constructor(
    private val controller: PlaybackController,
    private val libraryRepository: LibraryRepository
) : ViewModel() {
    val state: StateFlow<PlaybackState> = controller.state
    private var ticker: Job? = null

    init {
        ticker = viewModelScope.launch {
            while (true) {
                delay(500)
                controller.refresh()
            }
        }
    }

    fun play(song: Song, queue: List<Song> = listOf(song)) = playerCommand {
        if (controller.play(song, queue)) {
            libraryRepository.recordPlayed(song)
        }
    }

    fun toggle() = playerCommand { controller.toggle() }
    fun seek(positionMs: Long) = playerCommand { controller.seekTo(positionMs) }
    fun next() = playerCommand { controller.next() }
    fun previous() = playerCommand { controller.previous() }
    fun skipToQueueItem(index: Int) = playerCommand { controller.skipToQueueItem(index) }
    fun setShuffle(enabled: Boolean) = playerCommand { controller.setShuffleEnabled(enabled) }
    fun cycleRepeat() = playerCommand {
        val next = when (state.value.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        controller.setRepeatMode(next)
    }

    fun clearError() = controller.clearError()

    private fun playerCommand(block: suspend () -> Unit) = viewModelScope.launch {
        try {
            block()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            controller.setError(error.message?.takeIf { it.isNotBlank() } ?: "Playback unavailable")
        }
    }

    override fun onCleared() {
        ticker?.cancel()
        controller.release()
        super.onCleared()
    }
}
