package com.junaid.vibemusic3d.feature.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.junaid.vibemusic3d.feature.common.MusicArt
import com.junaid.vibemusic3d.feature.common.SongRow
import com.junaid.vibemusic3d.feature.library.LibraryViewModel
import com.junaid.vibemusic3d.playback.PlaybackViewModel

@Composable
fun SearchScreen(
    viewModel: SearchViewModel = hiltViewModel(),
    libraryViewModel: LibraryViewModel,
    playbackViewModel: PlaybackViewModel
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val favorites by libraryViewModel.favorites.collectAsStateWithLifecycle()
    val favoriteIds = favorites.asSequence().map { it.id }.toSet()

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp)) {
            Text("Search", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChanged,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Songs, artists, albums") },
                shape = MaterialTheme.shapes.extraLarge
            )
        }

        when {
            state.loading -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator()
            }
            state.error != null -> Column(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Search failed", style = MaterialTheme.typography.titleLarge)
                Text(state.error.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = viewModel::retry) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Text(" Retry")
                }
            }
            state.query.isBlank() -> Column(
                Modifier.fillMaxWidth().padding(top = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Search the catalog", style = MaterialTheme.typography.headlineSmall)
                Text("Try an artist, song or album", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> {
                val songs = state.result?.songs.orEmpty()
                val albums = state.result?.albums.orEmpty().take(8)
                val artists = state.result?.artists.orEmpty().take(8)
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item { Text("Songs", style = MaterialTheme.typography.titleLarge) }
                    if (songs.isEmpty()) item {
                        Text("No songs found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    items(songs, key = { it.id }) { song ->
                        SongRow(
                            song = song,
                            onPlay = { playbackViewModel.play(song, songs) },
                            onLike = { libraryViewModel.setFavorite(song, isLiked = song.id !in favoriteIds) },
                            isLiked = song.id in favoriteIds
                        )
                    }

                    if (artists.isNotEmpty()) item {
                        Text("Artists", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 14.dp))
                    }
                    if (artists.isNotEmpty()) item {
                        artists.forEach { artist ->
                            Row(
                                Modifier.fillMaxWidth().height(70.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                MusicArt(artist.imageUrl, Modifier.size(58.dp), 29.dp)
                                Column {
                                    Text(artist.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                    Text("Artist", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                }
                            }
                        }
                    }

                    if (albums.isNotEmpty()) item {
                        Text("Albums", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 14.dp))
                    }
                    if (albums.isNotEmpty()) item {
                        albums.forEach { album ->
                            Row(
                                Modifier.fillMaxWidth().height(70.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                MusicArt(album.imageUrl, Modifier.size(58.dp), 12.dp)
                                Column {
                                    Text(album.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                    Text(album.artistName.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(100.dp)) }
                }
            }
        }
    }
}
