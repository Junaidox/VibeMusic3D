package com.junaid.vibemusic3d.feature.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.junaid.vibemusic3d.data.local.LibraryRepository
import com.junaid.vibemusic3d.domain.model.Playlist
import com.junaid.vibemusic3d.domain.model.Song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repository: LibraryRepository
) : ViewModel() {
    val favorites: StateFlow<List<Song>> = repository.favorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val playlists: StateFlow<List<Playlist>> = repository.playlists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val recentlyPlayed: StateFlow<List<Song>> = repository.recentlyPlayed()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setFavorite(song: Song, isLiked: Boolean) = viewModelScope.launch {
        repository.setFavorite(song, isLiked)
    }

    fun removeFavorite(song: Song) = viewModelScope.launch {
        repository.setFavorite(song, false)
    }

    fun createPlaylist(name: String) = viewModelScope.launch {
        if (name.isNotBlank()) repository.createPlaylist(name.trim())
    }

    fun deletePlaylist(id: Long) = viewModelScope.launch {
        repository.deletePlaylist(id)
    }

    fun addToPlaylist(playlist: Playlist, song: Song) = viewModelScope.launch {
        repository.addToPlaylist(playlist.id, song)
    }
}
