# VibeMusic3D

Spotify-inspired 3D Android music app built with Kotlin + Jetpack Compose.

## Current feature set

- Home discovery feed
- Song / artist / album search
- 400ms debounced search
- Coil artwork loading
- Media3 ExoPlayer playback
- Background playback via MediaSessionService
- Lock-screen / media notification controls
- Queue, previous/next, shuffle, repeat
- Mini player + full player
- Favorites
- Room playlists
- Recently played history
- Dark depth / 3D-inspired Compose UI
- Configurable proxy backend

## Android build

Open the project root in Android Studio and let Gradle Sync finish. Then choose **Build > Build APK(s)**.

The debug APK will be at:

`app/build/outputs/apk/debug/app-debug.apk`

## Phone vs emulator backend

The default Android API base URL is `http://10.0.2.2:8787/`, which is for the Android emulator to reach a backend running on the development PC.

For a physical Android phone, do **not** use `10.0.2.2`. Set the Gradle property to a backend address reachable by the phone, for example:

`MUSIC_API_BASE_URL=http://192.168.1.20:8787/`

The PC and phone must be on the same network. For a public install, deploy the backend over HTTPS and set `MUSIC_API_BASE_URL` to its HTTPS base URL.

## Backend

The backend lives in `backend/`. It is an adapter/proxy around the upstream provider and exposes the app-specific `/v1/*` contract.

Run it with Node.js 20+ after installing dependencies in `backend/`.

Important: the upstream JioSaavn integration is unofficial. Review licensing/terms before public distribution.

## Verification

Source-level checks were performed in this sandbox. A full Android assemble requires the Android SDK and Gradle dependency resolution, which are not available in this execution environment.
