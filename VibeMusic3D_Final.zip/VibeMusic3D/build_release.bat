@echo off
setlocal
cd /d "%~dp0"
if not exist "gradle\wrapper\gradle-wrapper.jar" (
  echo Gradle wrapper JAR is missing.
  echo Open this project once in Android Studio and let Gradle sync, or run the Gradle wrapper generation script with a local Gradle install.
  exit /b 1
)
call gradlew.bat :app:assembleRelease
if errorlevel 1 exit /b %errorlevel%
echo.
echo APK: app\build\outputs\apk\release\app-release.apk
