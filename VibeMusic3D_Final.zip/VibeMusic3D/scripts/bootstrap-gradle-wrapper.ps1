$ErrorActionPreference = "Stop"

$version = "9.7.0"
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
    Write-Error "Gradle is not installed. Open the project in Android Studio or install Gradle ${version} first."
}

Write-Host "Generating Gradle wrapper for Gradle ${version}..."
gradle wrapper --gradle-version $version
Write-Host "Wrapper generated successfully."
