#!/usr/bin/env bash
set -euo pipefail
VERSION="9.7.0"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Open the project in Android Studio or install Gradle ${VERSION} first." >&2
  exit 1
fi
gradle wrapper --gradle-version "${VERSION}"
echo "Wrapper generated successfully."
