@echo off
setlocal
cd /d "%~dp0"
if not exist "gradle\wrapper\gradle-wrapper.jar" (
  echo Gradle wrapper JAR is missing. Open the project in Android Studio and sync first.
  exit /b 1
)
call gradlew.bat :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%
adb install -r app\build\outputs\apk\debug\app-debug.apk
if errorlevel 1 echo ADB install failed. Connect the phone, enable USB debugging, and retry.
