package com.junaid.vibemusic3d.data.repository

import com.junaid.vibemusic3d.data.remote.MusicApi
import com.junaid.vibemusic3d.data.remote.dto.SearchAllDto
import com.junaid.vibemusic3d.data.remote.dto.SearchAlbumDto
import com.junaid.vibemusic3d.data.remote.dto.SearchArtistDto
import com.junaid.vibemusic3d.data.remote.dto.SearchSongsDto
import com.junaid.vibemusic3d.data.remote.dto.SongDto
import com.junaid.vibemusic3d.domain.model.Album
import com.junaid.vibemusic3d.domain.model.Artist
import com.junaid.vibemusic3d.domain.model.HomeSection
import com.junaid.vibemusic3d.domain.model.SearchResult
import com.junaid.vibemusic3d.domain.model.Song
import com.junaid.vibemusic3d.domain.repository.MusicRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import javax.inject.Inject

class DefaultMusicRepository @Inject constructor(
    private val api: MusicApi
) : MusicRepository {
    override suspend fun search(query: String): Result<SearchResult> = resultOf {
        val response = api.search(query = query)
        if (!response.success) error(response.message ?: "Search failed")
        val data = response.data ?: error("Search returned no data")
        mapSearch(data)
    }

    override suspend fun getSong(id: String): Result<Song> = resultOf {
        val response = api.song(id)
        if (!response.success) error(response.message ?: "Song lookup failed")
        val dto = response.data?.firstOrNull() ?: error("Song not found")
        dto.toDomain() ?: error("Song data is incomplete")
    }

    override suspend fun getHome(): Result<List<HomeSection>> = resultOf {
        val queries = listOf("Trending Hindi", "New Hindi Songs", "Arijit Singh", "Bollywood Hits")
        coroutineScope {
            queries.map { query ->
                async {
                    val response = api.searchSongs(query = query, limit = 12)
                    if (!response.success) return@async null
                    val songs = response.data?.results.orEmpty().mapNotNull { it.toDomain() }
                    HomeSection(query, songs).takeIf { it.songs.isNotEmpty() }
                }
            }.mapNotNull { it.await() }
                .also { sections -> if (sections.isEmpty()) error("Music feed is unavailable") }
        }
    }

    private suspend fun <T> resultOf(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (error: kotlinx.coroutines.CancellationException) {
        throw error
    } catch (error: Throwable) {
        Result.failure(error)
    }

    private fun mapSearch(data: SearchAllDto): SearchResult {
        return SearchResult(
            songs = data.songs?.toSongs().orEmpty(),
            albums = data.albums?.results.orEmpty().map { it.toDomain() },
            artists = data.artists?.results.orEmpty().map { it.toDomain() }
        )
    }

    private fun SearchSongsDto.toSongs(): List<Song> = results.orEmpty().mapNotNull { it.toDomain() }

    private fun SongDto.toDomain(): Song? {
        val title = name?.takeIf { it.isNotBlank() } ?: return null
        val id = id?.takeIf { it.isNotBlank() } ?: return null
        val artist = artists?.primary.orEmpty().ifEmpty { artists?.all.orEmpty() }.firstOrNull()?.name
            ?: "Unknown artist"
        return Song(
            id = id,
            title = title,
            artistName = artist,
            albumName = album?.name,
            imageUrl = image.bestUrl(),
            streamUrl = streamUrl?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                ?: downloadUrl.bestUrl(),
            durationMs = duration?.takeIf { it > 0 }?.toLong()?.times(1000),
            url = url
        )
    }

    private fun SearchAlbumDto.toDomain() = Album(
        id = id.orEmpty(),
        name = title.orEmpty(),
        imageUrl = image.bestUrl(),
        artistName = artist
    )

    private fun SearchArtistDto.toDomain() = Artist(
        id = id.orEmpty(),
        name = title.orEmpty(),
        imageUrl = image.bestUrl()
    )

    private fun List<com.junaid.vibemusic3d.data.remote.dto.LinkDto>?.bestUrl(): String? =
        this.orEmpty()
            .asSequence()
            .sortedByDescending { qualityScore(it.quality) }
            .mapNotNull { it.url }
            .firstOrNull()

    private fun qualityScore(value: String?): Int = when {
        value.isNullOrBlank() -> 0
        value.contains("320") -> 320
        value.contains("160") -> 160
        value.contains("96") -> 96
        value.contains("500") -> 500
        value.contains("300") -> 300
        value.contains("150") -> 150
        else -> 1
    }
}
